Include'THlib.lua'

local _key_code_to_name={}
for k,v in pairs(KEY) do _key_code_to_name[v]=k end

function save_setting()
	local f,msg
	f,msg=io.open('setting','w')
	if f==nil then
		error(msg)
	else
		f:write(Serialize(cur_setting))
		f:close()
	end
end

stage_init=stage.New('init',true,true)
function stage_init:init()
	--
	local f,msg
	f,msg=io.open('setting','r')
	if f==nil then
		cur_setting=DeSerialize(Serialize(default_setting))
	else
		cur_setting=DeSerialize(f:read('*a'))
		f:close()
	end
	--
	local function ExitGame()
		task.New(self,function()
			task.Wait(30)
			stage.QuitGame()
		end)
	end
	--
	New(mask_fader,'open')
	--
	menu_title=New(simple_menu,'',{
		{'Start Game',function() menu.FlyIn(menu_mod,'right') menu.FlyOut(menu_title,'left') end},
		{'Set User Name',function() menu.FlyIn(menu_name,'right') menu.FlyOut(menu_title,'left') end},
		{'Key Settings',function() menu.FlyIn(menu_key,'right') menu.FlyOut(menu_title,'left') menu_key.pos=1 end},
		{'Other Settings',function() menu.FlyIn(menu_other,'right') menu.FlyOut(menu_title,'left') menu_other.pos=1 end},
		{'Exit Launcher',ExitGame},
		{'exit',function() if menu_title.pos==5 then ExitGame() else menu_title.pos=5 end end},
	})
	--
	menu_name=New(name_set_menu)
	--
	local menu_items={}
	local menu_mod_pos=1
	for mod_fn in lfs.dir('mod\\') do
		if lfs.attributes('mod\\'..mod_fn,'mode')~='directory' and string.sub(mod_fn,-4,-1)=='.zip' and mod_fn~='launcher.zip' then
			local mod_name=string.sub(mod_fn,1,-5)
			table.insert(menu_items,{mod_name,function()
				cur_setting.mod=mod_name save_setting()
				os.execute('start /b .\\LuaSTG.exe "start_game=true"')
				stage.QuitGame()
			end})
			if cur_setting.mod==mod_name then menu_mod_pos=#menu_items end
		end
	end
	table.insert(menu_items,{'exit',function() menu.FlyIn(menu_title,'left') menu.FlyOut(menu_mod,'right') end})
	menu_mod=New(simple_menu,'Select Game',menu_items)
	menu_mod.pos=menu_mod_pos
	--
	menu_key=New(key_setting_menu,'Key Settings',{
		{'Up',function() end},
		{'Down',function() end},
		{'Left',function() end},
		{'Right',function() end},
		{'Slow',function() end},
		{'Shoot',function() end},
		{'Spell',function() end},
		{'Special',function() end},
		{'RepFast',function() end},
		{'RepSlow',function() end},
		{'Menu',function() end},
		{'SnapShot',function() end},
	})
	--
	menu_other=New(other_setting_menu,'Other Settings',{
		{'Resolution X',function() menu_other.edit=true end},
		{'Resolution Y',function() menu_other.edit=true end},
		{'Windowed',function() cur_setting.windowed=not cur_setting.windowed end},
		{'Vsync',function() cur_setting.vsync=not cur_setting.vsync end},
		{'Sound Volume',function() end},
		{'Music Volume',function() end},
		{'Return To Title',function() menu.FlyIn(menu_title,'left') menu.FlyOut(menu_other,'right') save_setting() end},
		{'exit',function()
			if menu_other.pos~=7 then
				menu_other.pos=7
			else
				menu.FlyIn(menu_title,'left')
				menu.FlyOut(menu_other,'right')
				save_setting()
			end
		end},
	})
	--
	menu.FlyIn(menu_title,'right')
end
function stage_init:render()
	ui.DrawMenuBG()
end

name_set_menu=Class(object)

function name_set_menu:init()
	self.layer=LAYER_TOP
	self.group=GROUP_GHOST
	self.alpha=1
	self.matrix=''
	for i=0x20,0x7F do
		if i%16==15 then self.matrix=self.matrix..string.char(i)..'\n' else self.matrix=self.matrix..string.char(i) end
	end
	self.matrix=self.matrix..'\n'
	self.x=screen.width*0.5-448
	self.y=screen.height*0.5
	self.bound=false
	self.posx=1
	self.posy=4
	self.text=''
	self.forbidden={}
	self.title='Input User Name'
	self.locked=true
	self.text=cur_setting.username
end

function name_set_menu:frame()
	task.Do(self)
	if self.locked then return end
	if GetLastKey()==setting.keys.up    then self.posy=self.posy-1 PlaySound('select00',0.3) end
	if GetLastKey()==setting.keys.down  then self.posy=self.posy+1 PlaySound('select00',0.3) end
	if GetLastKey()==setting.keys.left  then self.posx=self.posx-1 PlaySound('select00',0.3) end
	if GetLastKey()==setting.keys.right then self.posx=self.posx+1 PlaySound('select00',0.3) end
	self.posx=(self.posx+16)%16
	self.posy=(self.posy+ 6)% 6
	if KeyIsPressed'shoot' then
		if self.posx==15 and self.posy==5 then
			if  self.text=='' then self.text='User' end
			PlaySound('ok00',0.3)
			cur_setting.username=self.text
			menu.FlyIn(menu_title,'left')
			menu.FlyOut(menu_name,'right')
			save_setting()
			return
		end
		if #self.text==16 then
			self.posx=15 self.posy=5
		else
			local char=string.char(0x20+self.posy*0x10+self.posx)
			self.text=self.text..char
			PlaySound('ok00',0.3)
		end
	elseif KeyIsPressed'spell' then
		PlaySound('cancel00',0.3)
		if #self.text==0 then
			self.text='User'
		else
			self.text=string.sub(self.text,1,-2)
		end
	end
end

function name_set_menu:render()
	SetImageState('white','',Color(self.alpha*192,  0,  0,  0))
	RenderRect('white',self.x-108,self.x+108,self.y-128,self.y+128)
	SetImageState('white','',Color(self.alpha*255,128,128,128))
	RenderRect('white',self.x+(self.posx-8)*12,self.x+(self.posx-7)*12,self.y+(2-self.posy)*23,self.y+(3-self.posy)*23)
	SetFontState('menu','',Color(self.alpha*255,  0,  0,  0))
	RenderText('menu',self.title..'\n\n'..self.matrix..self.text..string.rep('-',16-#self.text),self.x+1,self.y-1,0.5,'centerpoint')
	SetFontState('menu','',Color(self.alpha*255,255,255,255))
	RenderText('menu',self.title..'\n\n'..self.matrix..self.text..string.rep('-',16-#self.text),self.x,self.y,0.5,'centerpoint')
end

local key_func={'up','down','left','right','slow','shoot','spell','special','repfast','repslow','menu','snapshot'}

key_setting_menu=Class(simple_menu)

function key_setting_menu:init(title,content)
	simple_menu.init(self,title,content)
	self.w=20
end

function key_setting_menu:frame()
	task.Do(self)
	if self.locked then return end
	local last_key=GetLastKey()
	if last_key~=KEY.NULL then
		PlaySound('select00',0.3)
		if self.pos<=8 then
			cur_setting.keys[key_func[self.pos]]=last_key
		else
			cur_setting.keysys[key_func[self.pos]]=last_key
		end
		self.pos=self.pos+1
		if self.pos==13 then
			self.pos=12
			menu.FlyIn(menu_title,'left')
			menu.FlyOut(menu_key,'right')
			save_setting()
		end
	end
end

function key_setting_menu:render()
	SetImageState('white','',Color(self.alpha*192,  0,  0,  0))
	RenderRect('white',self.x-self.w*6-12,self.x+self.w*6+12,self.y-self.h*11.5-12,self.y+self.h*11.5+12)
	SetImageState('white','',Color(self.alpha*255,128,128,128))
	RenderRect('white',self.x-self.w*6,self.x+self.w*6,self.y+self.h*11.5-self.pos*23-23,self.y+self.h*11.5-self.pos*23-46)
	--
	SetFontState('menu','',Color(self.alpha*255,  0,  0,  0))
	RenderText('menu',self.text,self.x+1-self.w*6+12,self.y-1,0.5,'left','vcenter')
	SetFontState('menu','',Color(self.alpha*255,255,255,255))
	RenderText('menu',self.text,self.x  -self.w*6+12,self.y  ,0.5,'left','vcenter')
	--
	for i=1,8 do
		SetFontState('menu','',Color(self.alpha*255,  0,  0,  0))
		RenderText('menu',_key_code_to_name[cur_setting.keys[key_func[i]]],self.x+1+self.w*6-12,self.y-1+self.h*11.5-i*23-23,0.5,'right','top')
		SetFontState('menu','',Color(self.alpha*255,255,255,255))
		RenderText('menu',_key_code_to_name[cur_setting.keys[key_func[i]]],self.x  +self.w*6-12,self.y  +self.h*11.5-i*23-23,0.5,'right','top')
	end
	for i=9,12 do
		SetFontState('menu','',Color(self.alpha*255,  0,  0,  0))
		RenderText('menu',_key_code_to_name[cur_setting.keysys[key_func[i]]],self.x+1+self.w*6-12,self.y-1+self.h*11.5-i*23-23,0.5,'right','top')
		SetFontState('menu','',Color(self.alpha*255,255,255,255))
		RenderText('menu',_key_code_to_name[cur_setting.keysys[key_func[i]]],self.x  +self.w*6-12,self.y  +self.h*11.5-i*23-23,0.5,'right','top')
	end
	
end

local setting_item={'resx','resy','windowed','vsync','sevolume','bgmvolume'}

other_setting_menu=Class(simple_menu)

function other_setting_menu:init(title,content)
	simple_menu.init(self,title,content)
	self.w=24
	self.posx=1
end

function other_setting_menu:frame()
	task.Do(self)
	if self.locked then return end
	local last_key=GetLastKey()
	if last_key~=KEY.NULL then
		local item=setting_item[self.pos]
		if self.pos>=5 then
			if last_key==setting.keys.left then cur_setting[item]=max(0,cur_setting[item]-1) PlaySound('select00',0.3)
			elseif last_key==setting.keys.right then cur_setting[item]=min(100,cur_setting[item]+1) PlaySound('select00',0.3) end
		elseif self.pos<=2 then
			local step=10^(self.posx-1)
			if self.edit then
				if last_key==setting.keys.down then cur_setting[item]=cur_setting[item]-step PlaySound('select00',0.3)
				elseif last_key==setting.keys.up then cur_setting[item]=cur_setting[item]+step PlaySound('select00',0.3)
				elseif last_key==setting.keys.left then self.posx=self.posx+1 PlaySound('select00',0.3)
				elseif last_key==setting.keys.right then self.posx=self.posx-1 PlaySound('select00',0.3)
				elseif last_key==setting.keys.shoot then self.edit=false PlaySound('select00',0.3)
				end
				self.posx=max(1,min(self.posx,4))
				cur_setting[item]=max(1,min(cur_setting[item],9999))
				return
			end
		else
			if last_key==setting.keys.left or last_key==setting.keys.right then
				cur_setting[item]=not cur_setting[item]
				PlaySound('select00',0.3)
			end
		end
	end
	if not self.edit then simple_menu.frame(self) end
end

function other_setting_menu:render()
	SetImageState('white','',Color(self.alpha*192,  0,  0,  0))
	RenderRect('white',self.x-self.w*6-12,self.x+self.w*6+12,self.y-self.h*11.5-12,self.y+self.h*11.5+12)
	SetImageState('white','',Color(self.alpha*255,128,128,128))
	RenderRect('white',self.x-self.w*6,self.x+self.w*6,self.y+self.h*11.5-self.pos*23-23,self.y+self.h*11.5-self.pos*23-46)
	if self.pos<=2 and self.edit then
		if self.timer%30<15 then SetImageState('white','',Color(self.alpha*255,0,0,0)) end
		RenderRect('white',self.x+self.w*6-11-self.posx*12,self.x+self.w*6-self.posx*12,self.y+self.h*11.5-self.pos*23-23,self.y+self.h*11.5-self.pos*23-46)
	end
	--
	SetFontState('menu','',Color(self.alpha*255,  0,  0,  0))
	RenderText('menu',self.text,self.x+1-self.w*6+12,self.y-1,0.5,'left','vcenter')
	SetFontState('menu','',Color(self.alpha*255,255,255,255))
	RenderText('menu',self.text,self.x  -self.w*6+12,self.y  ,0.5,'left','vcenter')
	--
	for i=1,#setting_item do
		SetFontState('menu','',Color(self.alpha*255,  0,  0,  0))
		RenderText('menu',tostring(cur_setting[setting_item[i]]),self.x+1+self.w*6-12,self.y-1+self.h*11.5-i*23-23,0.5,'right','top')
		SetFontState('menu','',Color(self.alpha*255,255,255,255))
		RenderText('menu',tostring(cur_setting[setting_item[i]]),self.x  +self.w*6-12,self.y  +self.h*11.5-i*23-23,0.5,'right','top')
	end
end
