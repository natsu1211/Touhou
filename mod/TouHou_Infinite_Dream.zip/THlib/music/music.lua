music_list={
	--menu={'THlib\\music\\menu.mp3',62,0x8F3BF8/44100/4},
	menu={'THlib\\music\\menu_2.mp3',145,143},
	spellcard={'THlib\\music\\spellcard.mp3',75,0xc36e80/44100/4},
}