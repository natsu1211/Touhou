Include'THlib.lua'
Include'_editor_output.lua'