LoadTexture('bullet1','THlib\\bullet\\bullet1.png',true)
LoadImageGroup('preimg','bullet1',80,0,32,32,1,8)
LoadImageGroup('arrow_big','bullet1',0,0,16,16,1,16,4,4)
LoadImageGroup('gun_bullet','bullet1',24,0,16,16,1,16,4,3)
LoadImageGroup('gun_bullet_void','bullet1',56,0,16,16,1,16,4,3)
LoadImageGroup('butterfly','bullet1',112,0,32,32,1,8,4,4)
LoadImageGroup('square','bullet1',152,0,16,16,1,16,4,4)
LoadImageGroup('ball_mid','bullet1',176,0,32,32,1,8,4,4)
LoadImageGroup('mildew','bullet1',208,0,16,16,1,16,3,3)
LoadImageGroup('ellipse','bullet1',224,0,32,32,1,8,7,5)

LoadTexture('bullet2','THlib\\bullet\\bullet2.png')
LoadImageGroup('star_small','bullet2',96,0,16,16,1,16,3,3)
LoadImageGroup('star_big','bullet2',224,0,32,32,1,8,6,6)
LoadImageGroup('ball_huge','bullet2',0,0,64,64,1,4,20,20)
LoadImageGroup('fade_ball_huge','bullet2',0,0,64,64,1,4,20,20)
LoadImageGroup('ball_big','bullet2',192,0,32,32,1,8,8,8)
LoadImageGroup('ball_small','bullet2',176,0,16,16,1,16,2,2)
LoadImageGroup('grain_a','bullet2',160,0,16,16,1,16,3,3)
LoadImageGroup('grain_b','bullet2',128,0,16,16,1,16,3,3)

LoadTexture('bullet3','THlib\\bullet\\bullet3.png')
LoadAnimation('water_drop1','bullet3',176,0,32,32,1,4,4,6,6)
LoadAnimation('water_drop2','bullet3',176,128,32,32,1,4,4,6,6)
LoadAnimation('water_drop3','bullet3',224,0,32,32,1,4,4,6,6)
LoadAnimation('water_drop4','bullet3',224,128,32,32,1,4,4,6,6)
SetAnimationState('water_drop1','mul+add')
SetAnimationState('water_drop2','mul+add')
SetAnimationState('water_drop3','mul+add')
SetAnimationState('water_drop4','mul+add')
LoadImageGroup('knife','bullet3',0,0,32,32,1,8,12,3)
LoadImageGroup('grain_c','bullet3',48,0,16,16,1,16,3,3)
LoadImageGroup('arrow_small','bullet3',80,0,16,16,1,16,3,3)
LoadImageGroup('kite','bullet3',112,0,16,16,1,16,3,3)

bullet=Class(object)
function bullet:init(imgclass,index,stay,destroyable)
	self.logclass=self.class
	self.imgclass=imgclass
	self.class=imgclass
	if destroyable then self.group=GROUP_ENEMY_BULLET else self.group=GROUP_INDES end
	if type(index)=='number' then
		self.colli=false
		self.stay=stay
		index=int(min(max(1,index),16))
		self.layer=LAYER_ENEMY_BULLET_EF-imgclass.size*0.001+index*0.00001
		self._index=index
		self.index=int((index+1)/2)
	end
	imgclass.init(self,index)
end

function bullet:frame()
	task.Do(self)
end

function bullet:kill()
	New(item_faith_minor,self.x,self.y)
	self.imgclass.del(self)
end
function bullet:del()
	self.imgclass.del(self)
end
----------------------------------------------------------------
img_class=Class(object)
function img_class:frame()
	if not self.stay then
		self.logclass.frame(self)
	else
		self.x=self.x-self.vx
		self.y=self.y-self.vy
		self.rot=self.rot-self.omiga
	end
	if self.timer==11 then
		self.class=self.logclass
		self.layer=LAYER_ENEMY_BULLET-self.imgclass.size*0.001+self._index*0.00001
		self.colli=true
		if self.stay then self.timer=-1 end
	end
end
function img_class:del()
	New(bubble2,'preimg'..self.index,self.x,self.y,self.dx,self.dy,11,self.imgclass.size,0,Color(0xFFFFFFFF),Color(0xFFFFFFFF),self.layer,'mul+add')
end
function img_class:kill()
	img_class.del(self)
end
function img_class:render()
	SetImageState('preimg'..self.index,'',Color(255*self.timer/11,255,255,255))
	Render('preimg'..self.index,self.x,self.y,self.rot,((11-self.timer)/11*3+1)*self.imgclass.size)
end
----------------------------------------------------------------
function ChangeBulletImage(obj,imgclass,index)
	if obj.class==obj.imgclass then
		obj.class=imgclass
		obj.imgclass=imgclass
	else
		obj.imgclass=imgclass
	end
	obj._index=index
	imgclass.init(obj,obj._index)
end
----------------------------------------------------------------
particle_img=Class(object)
function particle_img:init(index)
	self.layer=LAYER_ENEMY_BULLET
	self.img=index
	self.class=self.logclass
end
function particle_img:del()
	misc.KeepParticle(self)
end
function particle_img:kill()
	particle_img.del(self)
end
----------------------------------------------------------------
arrow_big=Class(img_class)
arrow_big.size=0.6
function arrow_big:init(index)
	self.img='arrow_big'..index
end
----------------------------------------------------------------
gun_bullet=Class(img_class)
gun_bullet.size=0.4
function gun_bullet:init(index)
	self.img='gun_bullet'..index
end
----------------------------------------------------------------
butterfly=Class(img_class)
butterfly.size=0.7
function butterfly:init(index)
	self.img='butterfly'..int((index+1)/2)
end
----------------------------------------------------------------
square=Class(img_class)
square.size=0.8
function square:init(index)
	self.img='square'..index
end
----------------------------------------------------------------
ball_mid=Class(img_class)
ball_mid.size=0.75
function ball_mid:init(index)
	self.img='ball_mid'..int((index+1)/2)
end
----------------------------------------------------------------
mildew=Class(img_class)
mildew.size=0.401
function mildew:init(index)
	self.img='mildew'..index
end
----------------------------------------------------------------
ellipse=Class(img_class)
ellipse.size=0.701
function ellipse:init(index)
	self.img='ellipse'..int((index+1)/2)
end
----------------------------------------------------------------
star_small=Class(img_class)
star_small.size=0.5
function star_small:init(index)
	self.img='star_small'..index
end
----------------------------------------------------------------
star_big=Class(img_class)
star_big.size=0.998
function star_big:init(index)
	self.img='star_big'..int((index+1)/2)
end
----------------------------------------------------------------
ball_huge=Class(img_class)
ball_huge.size=2.0
function ball_huge:init(index)
	self.img='ball_huge'..int((index+3)/4)
end
function ball_huge:frame()
	if not self.stay then
		self.logclass.frame(self)
	else
		self.x=self.x-self.vx
		self.y=self.y-self.vy
		self.rot=self.rot-self.omiga
	end
	if self.timer==23 then
		self.class=self.logclass
		self.layer=LAYER_ENEMY_BULLET-2.0+self.index*0.00001
		self.colli=true
		if self.stay then self.timer=-1 end
	end
end
function ball_huge:render()
	SetImageState('fade_'..self.img,'',Color(255*self.timer/23,255,255,255))
	Render('fade_'..self.img,self.x,self.y,self.rot,(23-self.timer)/23+1)
end
function ball_huge:del()
	New(bubble2,'fade_'..self.img,self.x,self.y,self.dx,self.dy,11,1,0,Color(0xFFFFFFFF),Color(0x00FFFFFF),self.layer,'mul+add')
end
function ball_huge:kill()
	ball_huge.del(self)
end
----------------------------------------------------------------
ball_big=Class(img_class)
ball_big.size=1.0
function ball_big:init(index)
	self.img='ball_big'..int((index+1)/2)
end
----------------------------------------------------------------
ball_small=Class(img_class)
ball_small.size=0.402
function ball_small:init(index)
	self.img='ball_small'..index
end
----------------------------------------------------------------
grain_a=Class(img_class)
grain_a.size=0.403
function grain_a:init(index)
	self.img='grain_a'..index
end
----------------------------------------------------------------
grain_b=Class(img_class)
grain_b.size=0.404
function grain_b:init(index)
	self.img='grain_b'..index
end
----------------------------------------------------------------
grain_c=Class(img_class)
grain_c.size=0.405
function grain_c:init(index)
	self.img='grain_c'..index
end
----------------------------------------------------------------
kite=Class(img_class)
kite.size=0.406
function kite:init(index)
	self.img='kite'..index
end
----------------------------------------------------------------
knife=Class(img_class)
knife.size=0.751
function knife:init(index)
	self.img='knife'..int((index+1)/2)
end
----------------------------------------------------------------
arrow_small=Class(img_class)
arrow_small.size=0.407
function arrow_small:init(index)
	self.img='arrow_small'..index
end
----------------------------------------------------------------
water_drop=Class(img_class)
water_drop.size=0.702
function water_drop:init(index)
	self.img='water_drop'..int((index+3)/4)
	self.index=int((index+3)/4)*2-1
end
function water_drop:render()
	SetImageState('preimg'..self.index,'mul+add',Color(255*self.timer/11,255,255,255))
	Render('preimg'..self.index,self.x,self.y,self.rot,((11-self.timer)/11*2+1)*self.imgclass.size)
end
----------------------------------------------------------------

----------------------------------------------------------------
straight=Class(bullet)
function straight:init(imgclass,index,stay,x,y,v,angle,omiga)
	self.x=x self.y=y
	SetV(self,v,angle,true)
	self.omiga=omiga or 0
	bullet.init(self,imgclass,index,stay,true)
end
----------------------------------------------------------------
straight_indes=Class(bullet)
function straight_indes:init(imgclass,index,stay,x,y,v,angle,omiga)
	self.x=x self.y=y
	SetV(self,v,angle,true)
	self.omiga=omiga or 0
	bullet.init(self,imgclass,index,stay,false)
	self.group=GROUP_INDES
end
----------------------------------------------------------------
straight_495=Class(bullet)
function straight_495:init(imgclass,index,stay,x,y,v,angle,omiga)
	self.x=x self.y=y
	SetV(self,v,angle,true)
	self.omiga=omiga or 0
	bullet.init(self,imgclass,index,stay,true)
end
function straight_495:frame()
	if not self.reflected then
		if self.y> 224 then self.vy=-self.vy self.y= 448-self.y self.rot=   -self.rot self.reflected=true return end
		if self.x> 192 then self.vx=-self.vx self.x= 384-self.x self.rot=180-self.rot self.reflected=true return end
		if self.x<-192 then self.vx=-self.vx self.x=-384-self.x self.rot=180-self.rot self.reflected=true return end
	end
end
----------------------------------------------------------------
bullet_killer=Class(object)
function bullet_killer:init(x,y,kill_indes)
	self.x=x
	self.y=y
	self.group=GROUP_GHOST
	self.hide=true
	self.kill_indes=kill_indes
end
function bullet_killer:frame()
	if self.timer==40 then Del(self) end
	for i,o in ObjList(GROUP_ENEMY_BULLET) do
		if Dist(self,o)<self.timer*20 then Kill(o) end
	end
	if self.kill_indes then
		for i,o in ObjList(GROUP_INDES) do
			if Dist(self,o)<self.timer*20 then Kill(o) end
		end
	end
end
----------------------------------------------------------------
bullet_deleter=Class(object)
function bullet_deleter:init(x,y,kill_indes)
	self.x=x
	self.y=y
	self.group=GROUP_GHOST
	self.hide=true
	self.kill_indes=kill_indes
end
function bullet_deleter:frame()
	if self.timer==60 then Del(self) end
	for i,o in ObjList(GROUP_ENEMY_BULLET) do
		if Dist(self,o)<self.timer*20 then Del(o) end
	end
	if self.kill_indes then
		for i,o in ObjList(GROUP_INDES) do
			if Dist(self,o)<self.timer*20 then Del(o) end
		end
	end
end

COLOR_RED=2
COLOR_PURPLE=4
COLOR_BLUE=6
COLOR_CYAN=8
COLOR_GREEN=10
COLOR_YELLOW=12
COLOR_ORANGE=14
COLOR_GRAY=16
