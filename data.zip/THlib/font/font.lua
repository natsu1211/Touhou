LoadFont('score','THlib\\font\\score.fnt',false)
LoadFont('item','THlib\\font\\item.fnt',true)
LoadFont('menu','THlib\\font\\menu.fnt',false)
LoadFont('bonus','THlib\\font\\bonus.fnt',true)